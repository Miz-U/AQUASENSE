import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyATs5zIhqQaT0r8hutPR4Vliszulj11eyU",
  authDomain: "aquasense-c25b0.firebaseapp.com",
  databaseURL: "https://aquasense-c25b0-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "aquasense-c25b0",
  storageBucket: "aquasense-c25b0.firebasestorage.app",
  messagingSenderId: "824485414458",
  appId: "1:824485414458:web:0d9a94fbe7149937ded703",
  measurementId: "G-Z33XVLMNPK"
};